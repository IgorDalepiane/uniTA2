package Empresa.Exception;

public class CadastroException extends Exception {
    public CadastroException(String msg){
        super(msg);
    }
}
